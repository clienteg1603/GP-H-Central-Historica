# -*- coding: utf-8 -*-
"""
GP-H Consulta Histórica v0.1.13
Consulta leve do banco histórico da GP-H Central Histórica.

As consultas são somente-leitura. O botão Buscar atualização pode gravar exclusivamente
novos/corrigidos resultados na tabela resultados, sempre com backup automático.

- Menu: Início, Jogos do dia e Pesquisa.
- Lê o mesmo gph_historico.db da Central.
- Atualiza resultados pelo mesmo site da Central principal, sem tocar em jogos/financeiro/métodos.
- Pesquisa por bicho, grupo, dezena, centena, milhar, período, rodada e prêmio.
- Rankings de bichos, grupos, dezenas, centenas e milhares no recorte pesquisado.
- Somente biblioteca padrão do Python.
"""
from __future__ import annotations

import calendar
import csv
import html
import os
import re
import sqlite3
import sys
import threading
import unicodedata
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_NAME = "GP-H Consulta Histórica"
APP_VERSION = "0.1.13"

if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    APP_ROOT = Path(sys._MEIPASS)
else:
    APP_ROOT = Path(__file__).resolve().parent

ASSET_DIR = APP_ROOT / "assets"
ANIMAL_DIR = ASSET_DIR / "bichos"
LOGO_DIR = ASSET_DIR / "logo"
ICON_DIR = ASSET_DIR / "icons"

LOCAL_APPDATA = os.environ.get("LOCALAPPDATA")
if LOCAL_APPDATA:
    SETTINGS_DIR = Path(LOCAL_APPDATA) / "GP-H_Consulta_Historica"
    CENTRAL_DB = Path(LOCAL_APPDATA) / "GP-H_Central_Historica" / "dados" / "gph_historico.db"
else:
    SETTINGS_DIR = APP_ROOT / "dados_consulta"
    CENTRAL_DB = APP_ROOT / "dados_compartilhados" / "gph_historico.db"
SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = SETTINGS_DIR / "settings.txt"
# Mesma fonte pública usada pela GP-H Central Histórica principal para buscar resultados.
BASE_URL = "https://brasildeunoposte.com.br/resultado-do-jogo-do-bicho-deu-no-poste-{date}/"
WEB_UPDATE_START = date(2026, 1, 2)

BICHOS = {
    1: "AVESTRUZ", 2: "ÁGUIA", 3: "BURRO", 4: "BORBOLETA", 5: "CACHORRO",
    6: "CABRA", 7: "CARNEIRO", 8: "CAMELO", 9: "COBRA", 10: "COELHO",
    11: "CAVALO", 12: "ELEFANTE", 13: "GALO", 14: "GATO", 15: "JACARÉ",
    16: "LEÃO", 17: "MACACO", 18: "PORCO", 19: "PAVÃO", 20: "PERU",
    21: "TOURO", 22: "TIGRE", 23: "URSO", 24: "VEADO", 25: "VACA",
}

SORTEIO_ALIASES = {
    "PPT": "PPT", "PTM": "PTM", "PT": "PT", "PTV": "PTV", "PTN": "PTN",
    "FEDERAL": "FEDERAL", "CORUJA": "CORUJA", "CORUJINHA": "CORUJA",
}


def grupo_da_dezena(dezena: int) -> int:
    return (((int(dezena) - 1) % 100) // 4) + 1


def derivados_milhar(milhar: str):
    digits = re.sub(r"\D", "", str(milhar))
    if not digits:
        raise ValueError("Milhar vazia.")
    digits = digits[-4:].zfill(4)
    centena = digits[-3:]
    dezena = digits[-2:]
    grupo = grupo_da_dezena(int(dezena))
    return digits, centena, dezena, grupo, BICHOS[grupo]


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        if data and data.strip():
            self.parts.append(html.unescape(data).strip())

    def lines(self):
        out = []
        for part in self.parts:
            for line in re.split(r"[\r\n]+", part):
                line = re.sub(r"\s+", " ", line).strip()
                if line:
                    out.append(line)
        return out


HEADING_RE = re.compile(
    r"\b(PPT|PTM|PTV|PTN|PT|FEDERAL|CORUJA|CORUJINHA)\b.*?\bdas?\s+(\d{1,2}:\d{2})",
    re.I,
)
PRIZE_RE = re.compile(
    r"^\s*([1-5])\s*[°ºoª]?\s*=?\s*(\d{1,4})\s*[–—-]\s*(\d{1,2})\s+(.+?)\s*$",
    re.I,
)


@dataclass
class PrizeRow:
    data: str
    dia_semana: str
    sorteio: str
    hora: str
    premio: int
    milhar: str
    centena: str
    dezena: str
    grupo: int
    bicho: str
    fonte: str
    grupo_publicado: int | None = None
    bicho_publicado: str | None = None


def parse_daily_html(raw_html: str, day: date, fonte: str) -> list[PrizeRow]:
    parser = TextExtractor()
    parser.feed(raw_html)
    current_sorteio = None
    current_hora = None
    rows = []
    for line in parser.lines():
        h = HEADING_RE.search(line)
        if h:
            current_sorteio = SORTEIO_ALIASES.get(h.group(1).upper(), h.group(1).upper())
            current_hora = h.group(2).zfill(5)
            continue
        m = PRIZE_RE.match(line)
        if not m or not current_sorteio or not current_hora:
            continue
        premio = int(m.group(1))
        milhar_raw = m.group(2)
        grupo_pub = int(m.group(3))
        bicho_pub = m.group(4).strip()
        milhar, centena, dezena, grupo_calc, bicho_calc = derivados_milhar(milhar_raw)
        rows.append(PrizeRow(
            data=day.isoformat(), dia_semana=day.strftime("%A"),
            sorteio=current_sorteio, hora=current_hora, premio=premio,
            milhar=milhar, centena=centena, dezena=dezena, grupo=grupo_calc,
            bicho=bicho_calc, fonte=fonte, grupo_publicado=grupo_pub,
            bicho_publicado=bicho_pub,
        ))
    return rows


def fetch_day(day: date, timeout=18):
    url = BASE_URL.format(date=day.strftime("%d-%m-%Y"))
    req = urllib.request.Request(url, headers={
        "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) GPH-Consulta/{APP_VERSION}",
        "Accept-Language": "pt-BR,pt;q=0.9",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        content = resp.read()
        charset = resp.headers.get_content_charset() or "utf-8"
        raw = content.decode(charset, errors="replace")
    return url, parse_daily_html(raw, day, url)


def dezenas_grupo(grupo: int) -> tuple[str, str, str, str]:
    start = (grupo - 1) * 4 + 1
    vals = [((start + i - 1) % 100) + 1 for i in range(4)]
    return tuple(f"{v:02d}" for v in vals)

DEZENAS_POR_GRUPO = {g: dezenas_grupo(g) for g in range(1, 26)}

COLORS = {
    "bg": "#07111F",
    "sidebar": "#07101C",
    "card": "#101E30",
    "card2": "#0D1A2A",
    "text": "#EAF2FA",
    "muted": "#8CA0B4",
    "border": "#23364A",
    "accent": "#2F81F7",
    "accent_hover": "#4897FF",
    "entry": "#0B1827",
    "tree": "#0C1928",
    "selection": "#174B7A",
    "success": "#34D399",
    "warning": "#EAB308",
}


def sem_acento(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(text)) if unicodedata.category(c) != "Mn").upper()


def parse_date(text: str):
    text = (text or "").strip()
    if not text:
        return None
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError("Use a data no formato DD/MM/AAAA.")


def display_date(iso: str) -> str:
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d/%m/%Y")
    except Exception:
        return iso or "—"


def load_saved_db_path() -> Path | None:
    try:
        if SETTINGS_FILE.is_file():
            raw = SETTINGS_FILE.read_text(encoding="utf-8").strip()
            if raw:
                p = Path(raw).expanduser()
                if p.is_file():
                    return p
    except Exception:
        pass
    return None


def save_db_path(path: Path):
    try:
        SETTINGS_FILE.write_text(str(path), encoding="utf-8")
    except Exception:
        pass


def find_default_db() -> Path | None:
    env = os.environ.get("GPH_DB_PATH")
    candidates = []
    if env:
        candidates.append(Path(env).expanduser())
    saved = load_saved_db_path()
    if saved:
        candidates.append(saved)
    candidates.append(CENTRAL_DB)
    candidates.append(APP_ROOT / "dados" / "gph_historico.db")
    candidates.append(APP_ROOT / "dados_compartilhados" / "gph_historico.db")
    for p in candidates:
        try:
            if p.is_file():
                return p.resolve()
        except Exception:
            continue
    return None


def version_tuple(value: str):
    parts = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in (parts[:4] or [0]))


def tooltip_position(px, py, tw, th, sw, sh, margin=8, gap=14):
    """Posiciona tooltip dentro da tela; inverte para esquerda/cima nas bordas."""
    x = px + gap
    y = py + 16
    if x + tw > sw - margin:
        x = px - tw - gap
    if y + th > sh - margin:
        y = py - th - 12
    x = max(margin, min(x, sw - tw - margin))
    y = max(margin, min(y, sh - th - margin))
    return x, y


class HoverTip:
    """Tooltip leve que aparece ao manter o mouse sobre um widget."""
    def __init__(self, widget, text_func):
        self.widget = widget
        self.text_func = text_func
        self.tip = None
        self.after_id = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _=None):
        self._cancel()
        self.after_id = self.widget.after(350, self._show)

    def _cancel(self):
        if self.after_id:
            try: self.widget.after_cancel(self.after_id)
            except Exception: pass
            self.after_id = None

    def _show(self):
        self.after_id = None
        if self.tip or not self.widget.winfo_exists():
            return
        text = self.text_func() if callable(self.text_func) else str(self.text_func)
        if not text:
            return
        px = self.widget.winfo_pointerx()
        py = self.widget.winfo_pointery()
        tip = tk.Toplevel(self.widget)
        tip.wm_overrideredirect(True)
        try: tip.attributes("-topmost", True)
        except Exception: pass
        frame = tk.Frame(tip, bg="#13243A", highlightbackground=COLORS["accent"], highlightthickness=1)
        frame.pack()
        tk.Label(frame, text=text, justify="left", bg="#13243A", fg=COLORS["text"],
                 font=("Segoe UI", 9), padx=10, pady=7).pack()

        # Só posiciona depois de medir a janela. Nos bichos da coluna da direita,
        # abre para a esquerda quando não houver espaço, evitando corte na tela.
        tip.update_idletasks()
        tw = max(1, tip.winfo_reqwidth())
        th = max(1, tip.winfo_reqheight())
        sw = max(1, tip.winfo_screenwidth())
        sh = max(1, tip.winfo_screenheight())
        x, y = tooltip_position(px, py, tw, th, sw, sh)
        tip.geometry(f"+{x}+{y}")
        self.tip = tip

    def _hide(self, _=None):
        self._cancel()
        if self.tip:
            try: self.tip.destroy()
            except Exception: pass
            self.tip = None


MONTHS_PT = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
]
WEEKDAYS_PT = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]


class DatePickerPopup:
    """Calendário compacto para preencher um StringVar no formato dd/mm/aaaa."""
    def __init__(self, parent, target_var, anchor_widget, initial=None):
        self.parent = parent
        self.target_var = target_var
        self.anchor_widget = anchor_widget
        parsed = None
        raw = (target_var.get() or "").strip()
        for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(raw, fmt).date()
                break
            except Exception:
                pass
        self.current = parsed or initial or date.today()
        self.win = tk.Toplevel(parent)
        self.win.title("Selecionar data")
        self.win.configure(bg=COLORS["card"])
        self.win.resizable(False, False)
        self.win.transient(parent)
        try:
            self.win.attributes("-topmost", True)
        except Exception:
            pass
        self.win.bind("<Escape>", lambda e: self.close())
        self._build()
        self._position()
        try:
            self.win.grab_set()
        except Exception:
            pass

    def _build(self):
        head = tk.Frame(self.win, bg=COLORS["card"])
        head.pack(fill="x", padx=8, pady=(8, 4))
        tk.Button(head, text="‹", command=lambda: self._move_month(-1), bd=0, relief="flat",
                  bg=COLORS["card2"], fg=COLORS["text"], activebackground=COLORS["border"],
                  activeforeground=COLORS["text"], font=("Segoe UI Semibold", 13), width=3, cursor="hand2").pack(side="left")
        self.month_label = tk.Label(head, text="", bg=COLORS["card"], fg=COLORS["text"],
                                    font=("Segoe UI Semibold", 11), width=19)
        self.month_label.pack(side="left", padx=5)
        tk.Button(head, text="›", command=lambda: self._move_month(1), bd=0, relief="flat",
                  bg=COLORS["card2"], fg=COLORS["text"], activebackground=COLORS["border"],
                  activeforeground=COLORS["text"], font=("Segoe UI Semibold", 13), width=3, cursor="hand2").pack(side="right")

        self.grid = tk.Frame(self.win, bg=COLORS["card"])
        self.grid.pack(padx=8, pady=(0, 4))
        for c, name in enumerate(WEEKDAYS_PT):
            tk.Label(self.grid, text=name, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Segoe UI Semibold", 8), width=4).grid(row=0, column=c, padx=1, pady=1)

        foot = tk.Frame(self.win, bg=COLORS["card"])
        foot.pack(fill="x", padx=8, pady=(3, 8))
        tk.Button(foot, text="Limpar", command=self._clear, bd=0, relief="flat", cursor="hand2",
                  bg=COLORS["card2"], fg=COLORS["muted"], activebackground=COLORS["border"],
                  activeforeground=COLORS["text"], font=("Segoe UI", 9), padx=9, pady=5).pack(side="left")
        tk.Button(foot, text="Hoje", command=lambda: self._choose(date.today()), bd=0, relief="flat", cursor="hand2",
                  bg=COLORS["accent"], fg="white", activebackground=COLORS["accent_hover"],
                  activeforeground="white", font=("Segoe UI Semibold", 9), padx=11, pady=5).pack(side="right")
        self._render_month()

    def _render_month(self):
        for w in list(self.grid.grid_slaves()):
            info = w.grid_info()
            if int(info.get("row", 0)) > 0:
                w.destroy()
        y, m = self.current.year, self.current.month
        self.month_label.configure(text=f"{MONTHS_PT[m-1]} {y}")
        cal = calendar.Calendar(firstweekday=0)
        weeks = cal.monthdayscalendar(y, m)
        today = date.today()
        selected = None
        raw = (self.target_var.get() or "").strip()
        for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
            try:
                selected = datetime.strptime(raw, fmt).date()
                break
            except Exception:
                pass
        for r, week in enumerate(weeks, start=1):
            for c, day_num in enumerate(week):
                if day_num == 0:
                    tk.Label(self.grid, text="", bg=COLORS["card"], width=4).grid(row=r, column=c, padx=1, pady=1)
                    continue
                d = date(y, m, day_num)
                is_sel = selected == d
                is_today = today == d
                bg = COLORS["accent"] if is_sel else (COLORS["selection"] if is_today else COLORS["card2"])
                fg = "white" if (is_sel or is_today) else COLORS["text"]
                tk.Button(self.grid, text=str(day_num), command=lambda x=d: self._choose(x),
                          bd=0, relief="flat", cursor="hand2", width=3,
                          bg=bg, fg=fg, activebackground=COLORS["accent_hover"], activeforeground="white",
                          font=("Segoe UI Semibold" if is_sel else "Segoe UI", 9), pady=3).grid(row=r, column=c, padx=1, pady=1)

    def _move_month(self, delta):
        y, m = self.current.year, self.current.month
        m += delta
        if m < 1:
            m = 12; y -= 1
        elif m > 12:
            m = 1; y += 1
        self.current = date(y, m, 1)
        self._render_month()

    def _choose(self, value):
        self.target_var.set(value.strftime("%d/%m/%Y"))
        self.close()

    def _clear(self):
        self.target_var.set("")
        self.close()

    def _position(self):
        self.win.update_idletasks()
        try:
            x = self.anchor_widget.winfo_rootx()
            y = self.anchor_widget.winfo_rooty() + self.anchor_widget.winfo_height() + 4
        except Exception:
            x = self.parent.winfo_pointerx(); y = self.parent.winfo_pointery()
        ww, wh = self.win.winfo_reqwidth(), self.win.winfo_reqheight()
        sw, sh = self.win.winfo_screenwidth(), self.win.winfo_screenheight()
        x = max(8, min(x, sw - ww - 8))
        if y + wh > sh - 8:
            try:
                y = self.anchor_widget.winfo_rooty() - wh - 4
            except Exception:
                y = max(8, sh - wh - 8)
        y = max(8, min(y, sh - wh - 8))
        self.win.geometry(f"+{x}+{y}")

    def close(self):
        try:
            self.win.grab_release()
        except Exception:
            pass
        try:
            self.win.destroy()
        except Exception:
            pass


class HistoryReader:
    """Acesso estritamente somente-leitura ao banco histórico."""
    def __init__(self, path: Path | None = None):
        self.path = Path(path).resolve() if path else None

    def available(self) -> bool:
        return bool(self.path and self.path.is_file())

    def set_path(self, path: Path):
        path = Path(path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError("Banco não encontrado.")
        uri = f"file:{path.as_posix()}?mode=ro"
        con = sqlite3.connect(uri, uri=True, timeout=5)
        try:
            row = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='resultados'").fetchone()
            if not row:
                raise ValueError("Este arquivo não possui a tabela histórica 'resultados'.")
            cols = {r[1] for r in con.execute("PRAGMA table_info(resultados)").fetchall()}
            needed = {"data", "sorteio", "hora", "premio", "milhar", "centena", "dezena", "grupo", "bicho"}
            if not needed.issubset(cols):
                raise ValueError("A estrutura desse banco não é compatível com a GP-H.")
        finally:
            con.close()
        self.path = path
        save_db_path(path)

    def connect(self):
        if not self.available():
            raise FileNotFoundError("A base histórica ainda não foi localizada.")
        uri = f"file:{self.path.as_posix()}?mode=ro"
        con = sqlite3.connect(uri, uri=True, timeout=8)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA query_only=ON")
        return con

    def max_date(self):
        if not self.available():
            return None
        with self.connect() as con:
            row = con.execute("SELECT MAX(data) FROM resultados").fetchone()
        if not row or not row[0]:
            return None
        return datetime.strptime(row[0], "%Y-%m-%d").date()

    def compare_web_rows(self, rows):
        if not rows:
            return [], [], 0
        keys = {}
        start = min(r.data for r in rows)
        end = max(r.data for r in rows)
        with self.connect() as con:
            current = con.execute(
                "SELECT data,sorteio,hora,premio,milhar,grupo,bicho FROM resultados WHERE data>=? AND data<=?",
                (start, end),
            ).fetchall()
        for r in current:
            keys[(r["data"], r["sorteio"], r["hora"], int(r["premio"]))] = r
        novos, alterados, iguais = [], [], 0
        for r in rows:
            old = keys.get((r.data, r.sorteio, r.hora, r.premio))
            if old is None:
                novos.append(r)
            elif (old["milhar"] != r.milhar or int(old["grupo"]) != r.grupo or sem_acento(old["bicho"]) != sem_acento(r.bicho)):
                alterados.append((r, dict(old)))
            else:
                iguais += 1
        return novos, alterados, iguais

    def create_update_backup(self):
        if not self.available():
            raise FileNotFoundError("Base histórica não localizada.")
        backup_dir = self.path.parent / "backups_automaticos"
        try:
            backup_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            backup_dir = SETTINGS_DIR / "backups_automaticos"
            backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = backup_dir / f"GP-H_Consulta_antes_atualizacao_{stamp}.db"
        # Usa a API de backup do SQLite para obter cópia consistente mesmo se a
        # Central principal estiver aberta em outra conexão.
        src = sqlite3.connect(str(self.path), timeout=15)
        dst = sqlite3.connect(str(target))
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        old = sorted(backup_dir.glob("GP-H_Consulta_antes_atualizacao_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        for extra in old[10:]:
            try: extra.unlink()
            except Exception: pass
        return target

    def apply_web_rows(self, rows):
        """Grava exclusivamente a tabela resultados; nenhum outro dado da Central é tocado."""
        if not rows:
            return 0
        if not self.available():
            raise FileNotFoundError("Base histórica não localizada.")
        con = sqlite3.connect(str(self.path), timeout=15)
        try:
            con.execute("PRAGMA busy_timeout=15000")
            cols = {r[1] for r in con.execute("PRAGMA table_info(resultados)").fetchall()}
            optional = [c for c in ("dia_semana", "fonte", "grupo_publicado", "bicho_publicado") if c in cols]
            update_cols = ["milhar","centena","dezena","grupo","bicho"] + optional
            set_sql = ",".join(f"{c}=?" for c in update_cols)
            if "atualizado_em" in cols:
                set_sql += ",atualizado_em=CURRENT_TIMESTAMP"
            insert_cols = ["data","sorteio","hora","premio","milhar","centena","dezena","grupo","bicho"] + optional
            insert_sql = f"INSERT INTO resultados ({','.join(insert_cols)}) VALUES ({','.join('?' for _ in insert_cols)})"
            count = 0
            for r in rows:
                mapping = {
                    "data": r.data, "dia_semana": r.dia_semana, "sorteio": r.sorteio, "hora": r.hora,
                    "premio": r.premio, "milhar": r.milhar, "centena": r.centena, "dezena": r.dezena,
                    "grupo": r.grupo, "bicho": r.bicho, "fonte": r.fonte,
                    "grupo_publicado": r.grupo_publicado, "bicho_publicado": r.bicho_publicado,
                }
                cur = con.execute(
                    f"UPDATE resultados SET {set_sql} WHERE data=? AND sorteio=? AND hora=? AND premio=?",
                    [mapping[c] for c in update_cols] + [r.data, r.sorteio, r.hora, r.premio],
                )
                if cur.rowcount == 0:
                    con.execute(insert_sql, [mapping[c] for c in insert_cols])
                count += 1
            con.commit()
            return count
        finally:
            con.close()

    def summary(self):
        if not self.available():
            return {"premios": 0, "extracoes": 0, "dias": 0, "inicio": None, "fim": None, "ultimo": []}
        with self.connect() as con:
            row = con.execute("""
                SELECT COUNT(*) premios,
                       COUNT(DISTINCT data || '|' || sorteio || '|' || hora) extracoes,
                       COUNT(DISTINCT data) dias,
                       MIN(data) inicio, MAX(data) fim
                FROM resultados
            """).fetchone()
            last_key = con.execute("""
                SELECT data, sorteio, hora FROM resultados
                ORDER BY data DESC, hora DESC, sorteio DESC LIMIT 1
            """).fetchone()
            ultimo = []
            if last_key:
                ultimo = con.execute("""
                    SELECT * FROM resultados
                    WHERE data=? AND sorteio=? AND hora=?
                    ORDER BY premio
                """, tuple(last_key)).fetchall()
            destaques = {}
            for field in ("bicho", "milhar", "centena", "dezena"):
                top = con.execute(
                    f"SELECT {field} valor, COUNT(*) n FROM resultados "
                    f"GROUP BY {field} ORDER BY n DESC, {field} ASC LIMIT 1"
                ).fetchone()
                destaques[field] = (top["valor"], int(top["n"])) if top else (None, 0)
            return {
                "premios": row["premios"] or 0,
                "extracoes": row["extracoes"] or 0,
                "dias": row["dias"] or 0,
                "inicio": row["inicio"],
                "fim": row["fim"],
                "ultimo": ultimo,
                "destaques": destaques,
            }

    def draw_options(self, date_from=None, date_to=None):
        """Retorna somente as rodadas que existem no recorte de datas informado."""
        if not self.available():
            return []
        where = []
        args = []
        if date_from:
            where.append("data >= ?")
            args.append(date_from)
        if date_to:
            where.append("data <= ?")
            args.append(date_to)
        sql_where = (" WHERE " + " AND ".join(where)) if where else ""
        with self.connect() as con:
            rows = con.execute(
                "SELECT DISTINCT sorteio, hora FROM resultados" + sql_where +
                " ORDER BY substr(hora,1,2), substr(hora,4,2), sorteio",
                args,
            ).fetchall()
            return [(r["sorteio"], r["hora"]) for r in rows]


    def day_draws(self, day_value):
        """Retorna todas as extrações de uma data, agrupadas por sorteio/horário."""
        if not self.available():
            return []
        if isinstance(day_value, date):
            day_iso = day_value.isoformat()
        else:
            value = str(day_value or "").strip()
            parsed = None
            for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
                try:
                    parsed = datetime.strptime(value, fmt).date()
                    break
                except ValueError:
                    pass
            if parsed is None:
                raise ValueError("Data inválida. Use dd/mm/aaaa.")
            day_iso = parsed.isoformat()
        with self.connect() as con:
            rows = con.execute(
                "SELECT * FROM resultados WHERE data=? "
                "ORDER BY substr(hora,1,2), substr(hora,4,2), sorteio, premio",
                (day_iso,),
            ).fetchall()
        grouped = []
        by_key = {}
        for raw in rows:
            row = dict(raw)
            key = (row.get("sorteio") or "", row.get("hora") or "")
            item = by_key.get(key)
            if item is None:
                item = {
                    "data": day_iso,
                    "sorteio": key[0],
                    "hora": key[1],
                    "premios": [],
                }
                by_key[key] = item
                grouped.append(item)
            item["premios"].append(row)
        return grouped

    def _filters_sql(self, tipo="Todos", valor="", date_from=None, date_to=None,
                     sorteio=None, hora=None, premio=None):
        where = []
        args = []
        if date_from:
            where.append("data >= ?"); args.append(date_from)
        if date_to:
            where.append("data <= ?"); args.append(date_to)
        if sorteio and sorteio != "Todos":
            where.append("sorteio = ?"); args.append(sorteio)
        if hora and hora != "Todos":
            where.append("hora = ?"); args.append(hora)
        if premio and str(premio) != "Todos":
            p = int(str(premio).replace("º", "").strip())
            if p < 1 or p > 5:
                raise ValueError("Prêmio deve estar entre 1 e 5.")
            where.append("premio = ?"); args.append(p)

        tipo = (tipo or "Todos").strip()
        valor = (valor or "").strip()
        if valor:
            if tipo == "Bicho":
                target = sem_acento(valor)
                groups = [g for g, n in BICHOS.items() if target in sem_acento(n)]
                if not groups:
                    where.append("1=0")
                else:
                    where.append("grupo IN (%s)" % ",".join("?" * len(groups)))
                    args.extend(groups)
            elif tipo == "Grupo":
                try:
                    g = int(valor)
                except ValueError:
                    raise ValueError("Grupo deve ser um número de 1 a 25.")
                if not 1 <= g <= 25:
                    raise ValueError("Grupo deve ser um número de 1 a 25.")
                where.append("grupo = ?"); args.append(g)
            elif tipo in ("Dezena", "Centena", "Milhar"):
                sizes = {"Dezena": 2, "Centena": 3, "Milhar": 4}
                if not re.fullmatch(r"\d+", valor):
                    raise ValueError(f"{tipo} deve conter somente números.")
                field = tipo.lower()
                where.append(f"{field} = ?")
                args.append(valor.zfill(sizes[tipo])[-sizes[tipo]:])
            else:
                # Pesquisa geral: número exato quando numérico ou nome do bicho quando texto.
                if valor.isdigit():
                    raw = valor
                    clauses = ["milhar = ?", "centena = ?", "dezena = ?"]
                    subargs = [raw.zfill(4)[-4:], raw.zfill(3)[-3:], raw.zfill(2)[-2:]]
                    try:
                        g = int(raw)
                        if 1 <= g <= 25:
                            clauses.append("grupo = ?"); subargs.append(g)
                    except Exception:
                        pass
                    where.append("(" + " OR ".join(clauses) + ")")
                    args.extend(subargs)
                else:
                    target = sem_acento(valor)
                    groups = [g for g, n in BICHOS.items() if target in sem_acento(n)]
                    if not groups:
                        where.append("1=0")
                    else:
                        where.append("grupo IN (%s)" % ",".join("?" * len(groups)))
                        args.extend(groups)
        sql = " WHERE " + " AND ".join(where) if where else ""
        return sql, args

    def search(self, **filters):
        if not self.available():
            return []
        sql, args = self._filters_sql(**filters)
        with self.connect() as con:
            return con.execute(
                "SELECT data,sorteio,hora,premio,milhar,centena,dezena,grupo,bicho "
                "FROM resultados" + sql + " ORDER BY data DESC, hora DESC, premio ASC",
                args,
            ).fetchall()

    def group_counts(self):
        if not self.available():
            return {g: 0 for g in BICHOS}
        with self.connect() as con:
            counts = {g: 0 for g in BICHOS}
            for r in con.execute("SELECT grupo, COUNT(*) n FROM resultados GROUP BY grupo"):
                counts[int(r["grupo"])] = int(r["n"])
            return counts

    def last_group_occurrences(self):
        if not self.available():
            return {}
        with self.connect() as con:
            rows = con.execute("""
                SELECT grupo, data, sorteio, hora, premio, milhar
                FROM resultados
                ORDER BY data DESC, hora DESC, sorteio DESC, premio ASC
            """).fetchall()
            out = {}
            for r in rows:
                out.setdefault(int(r["grupo"]), r)
                if len(out) == 25:
                    break
            return out

    def delay_leaders(self):
        """Mais atrasados por quantidade de extrações desde a última aparição.

        A contagem usa a extração (data+sorteio+hora) como unidade, e não cada prêmio.
        Para centena/dezena entram somente valores que já apareceram na base, evitando
        classificar um valor nunca observado como se fosse apenas "atrasado".
        Empates são preservados; a UI não inventa um vencedor entre valores empatados.
        """
        empty = {"bicho": None, "centena": None, "dezena": None, "total_extracoes": 0}
        if not self.available():
            return empty
        with self.connect() as con:
            rows = con.execute("""
                SELECT data,sorteio,hora,premio,milhar,centena,dezena,grupo,bicho
                FROM resultados
                ORDER BY data ASC, hora ASC, sorteio ASC, premio ASC
            """).fetchall()
        if not rows:
            return empty

        draw_keys = []
        draw_index = {}
        for r in rows:
            key = (r["data"], r["sorteio"], r["hora"])
            if key not in draw_index:
                draw_index[key] = len(draw_keys)
                draw_keys.append(key)
        newest_idx = len(draw_keys) - 1

        last_seen = {"bicho": {}, "centena": {}, "dezena": {}}
        last_row = {"bicho": {}, "centena": {}, "dezena": {}}
        for r in rows:
            idx = draw_index[(r["data"], r["sorteio"], r["hora"])]
            values = {
                "bicho": int(r["grupo"]),
                "centena": str(r["centena"]).zfill(3),
                "dezena": str(r["dezena"]).zfill(2),
            }
            for field, value in values.items():
                # Qualquer ocorrência dentro da mesma extração conta uma única vez.
                if idx >= last_seen[field].get(value, -1):
                    last_seen[field][value] = idx
                    last_row[field][value] = dict(r)

        # Bichos têm universo conhecido de 25 grupos. Em uma base histórica normal todos
        # já apareceram; se algum nunca apareceu, não o rotulamos como atrasado.
        result = {"total_extracoes": len(draw_keys)}
        for field in ("bicho", "centena", "dezena"):
            if not last_seen[field]:
                result[field] = None
                continue
            delays = {value: newest_idx - idx for value, idx in last_seen[field].items()}
            max_delay = max(delays.values())
            tied = sorted(
                [value for value, delay in delays.items() if delay == max_delay],
                key=lambda v: (int(v) if str(v).isdigit() else str(v)),
            )
            first = tied[0]
            result[field] = {
                "value": first,
                "delay": int(max_delay),
                "ties": tied,
                "tie_count": len(tied),
                "last": last_row[field][first],
            }
        return result


class ConsultaApp(tk.Tk):
    def __init__(self, db_path: Path | None = None):
        super().__init__()
        self.reader = HistoryReader(db_path or find_default_db())
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1280x760")
        self.minsize(980, 620)
        try:
            ico = LOGO_DIR / "gph_icon.ico"
            if ico.is_file():
                self.iconbitmap(str(ico))
        except Exception:
            pass
        self.configure(bg=COLORS["bg"])
        self._images = {}
        self.last_rows = []
        self.active_page = ""
        self.nav_buttons = {}
        self._tooltips = []
        self._configure_styles()
        self._build_shell()
        self.show_home()
        try:
            if sys.platform.startswith("win"):
                self.state("zoomed")
        except Exception:
            pass

    def _configure_styles(self):
        s = ttk.Style(self)
        try: s.theme_use("clam")
        except Exception: pass
        s.configure("TFrame", background=COLORS["bg"])
        s.configure("Card.TFrame", background=COLORS["card"])
        s.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI", 10))
        s.configure("Card.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=("Segoe UI", 10))
        s.configure("Title.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI Semibold", 22))
        s.configure("Subtitle.TLabel", background=COLORS["bg"], foreground=COLORS["muted"], font=("Segoe UI", 10))
        s.configure("Big.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=("Segoe UI Semibold", 18))
        s.configure("MutedCard.TLabel", background=COLORS["card"], foreground=COLORS["muted"], font=("Segoe UI", 9))
        s.configure("Accent.TButton", font=("Segoe UI Semibold", 10), padding=(12, 7), background=COLORS["accent"], foreground="white")
        s.map("Accent.TButton", background=[("active", COLORS["accent_hover"])])
        s.configure("TButton", font=("Segoe UI", 10), padding=(10, 6), background=COLORS["card2"], foreground=COLORS["text"])
        s.map("TButton", background=[("active", COLORS["border"])])
        s.configure("TEntry", fieldbackground=COLORS["entry"], foreground=COLORS["text"], insertcolor=COLORS["text"], padding=6)
        # Combobox escuro também no estado readonly. Em alguns temas do Windows,
        # apenas fieldbackground não é suficiente e o campo volta a ficar branco.
        s.configure("TCombobox", fieldbackground=COLORS["entry"], background=COLORS["entry"], foreground=COLORS["text"], arrowcolor=COLORS["text"], padding=5)
        s.map("TCombobox",
              fieldbackground=[("readonly", COLORS["entry"]), ("disabled", COLORS["card2"])],
              background=[("readonly", COLORS["entry"]), ("active", COLORS["card2"])],
              foreground=[("readonly", COLORS["text"]), ("disabled", COLORS["muted"])],
              selectbackground=[("readonly", COLORS["entry"])],
              selectforeground=[("readonly", COLORS["text"])])
        # A lista suspensa do ttk.Combobox usa um Listbox separado no Windows.
        self.option_add("*TCombobox*Listbox.background", COLORS["entry"])
        self.option_add("*TCombobox*Listbox.foreground", COLORS["text"])
        self.option_add("*TCombobox*Listbox.selectBackground", COLORS["selection"])
        self.option_add("*TCombobox*Listbox.selectForeground", "white")
        s.configure("Treeview", background=COLORS["tree"], fieldbackground=COLORS["tree"], foreground=COLORS["text"], rowheight=26, font=("Segoe UI", 9), borderwidth=0)
        s.configure("Treeview.Heading", background=COLORS["card2"], foreground=COLORS["text"], font=("Segoe UI Semibold", 9), relief="flat")
        s.map("Treeview", background=[("selected", COLORS["selection"])], foreground=[("selected", "white")])

    def _load_image(self, key, path: Path, subsample=1):
        cache_key = (key, subsample)
        if cache_key in self._images:
            return self._images[cache_key]
        try:
            img = tk.PhotoImage(file=str(path))
            if subsample > 1:
                img = img.subsample(subsample, subsample)
            self._images[cache_key] = img
            return img
        except Exception:
            return None

    def _build_shell(self):
        self.sidebar = tk.Frame(self, bg=COLORS["sidebar"], width=205)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo = self._load_image("logo", LOGO_DIR / "gph_logo_sidebar.png", 2)
        if logo:
            tk.Label(self.sidebar, image=logo, bg=COLORS["sidebar"]).pack(pady=(22, 6))
        tk.Label(self.sidebar, text="CONSULTA HISTÓRICA", bg=COLORS["sidebar"], fg=COLORS["muted"], font=("Segoe UI Semibold", 9)).pack(pady=(0, 22))

        for key, text, icon_name, command in (
            ("home", "Início", "home", self.show_home),
            ("day_games", "Jogos do dia", "results", self.show_day_games),
            ("search", "Pesquisa", "search", self.show_search),
        ):
            icon = self._load_image(f"nav_{icon_name}", ICON_DIR / f"{icon_name}.png")
            b = tk.Button(self.sidebar, text="  " + text, image=icon, compound="left" if icon else "none",
                          anchor="w", padx=18, pady=12, bd=0, relief="flat", cursor="hand2",
                          bg=COLORS["sidebar"], fg=COLORS["muted"], activebackground=COLORS["card2"],
                          activeforeground=COLORS["text"], font=("Segoe UI Semibold", 11), command=command)
            b.pack(fill="x", padx=10, pady=3)
            self.nav_buttons[key] = b

        tk.Frame(self.sidebar, bg=COLORS["sidebar"]).pack(fill="both", expand=True)
        # v0.1.10: atualização fica no cartão da base; seleção de base permanece apenas no menu lateral
        # Base / Atualização da Home, seguindo a organização visual da Central principal.
        self.update_btn = None
        self.base_state = tk.Label(self.sidebar, text="", justify="left", wraplength=175,
                                   bg=COLORS["sidebar"], fg=COLORS["muted"], font=("Segoe UI", 8))
        self.base_state.pack(fill="x", padx=15, pady=(5, 8))
        tk.Button(self.sidebar, text="Selecionar base", command=self.choose_database,
                  bd=0, relief="flat", cursor="hand2", bg=COLORS["card2"], fg=COLORS["text"],
                  activebackground=COLORS["border"], activeforeground=COLORS["text"],
                  font=("Segoe UI", 9), pady=7).pack(fill="x", padx=12, pady=(0, 18))

        self.main = tk.Frame(self, bg=COLORS["bg"])
        self.main.pack(side="left", fill="both", expand=True)
        self.content = tk.Frame(self.main, bg=COLORS["bg"])
        self.content.pack(fill="both", expand=True, padx=24, pady=18)
        self._update_base_state()

    def _update_base_state(self):
        if self.reader.available():
            self.base_state.configure(text=f"Consultas em leitura • atualização controlada\n{self.reader.path}", fg=COLORS["success"])
        else:
            self.base_state.configure(text="Base histórica não localizada.\nSelecione o gph_historico.db.", fg=COLORS["warning"])

    def _set_active(self, key):
        self.active_page = key
        for k, b in self.nav_buttons.items():
            if k == key:
                b.configure(bg=COLORS["selection"], fg="white")
            else:
                b.configure(bg=COLORS["sidebar"], fg=COLORS["muted"])

    def _clear(self):
        for w in self.content.winfo_children():
            w.destroy()

    def _page_header(self, title, subtitle):
        ttk.Label(self.content, text=title, style="Title.TLabel").pack(anchor="w")
        ttk.Label(self.content, text=subtitle, style="Subtitle.TLabel").pack(anchor="w", pady=(2, 15))

    def check_for_updates(self):
        """Busca resultados novos/corrigidos usando a mesma fonte da Central principal."""
        if not self.reader.available():
            messagebox.showwarning("Atualizar resultados", "Selecione a base histórica primeiro.", parent=self)
            return
        if getattr(self, "_web_update_running", False):
            return
        self._web_update_running = True
        self._set_update_button_state("↻  BUSCANDO...", "disabled")
        threading.Thread(target=self._web_update_worker, daemon=True).start()

    def _web_update_worker(self):
        rows = []
        errors = []
        try:
            today = date.today()
            last = self.reader.max_date()
            if last:
                start = max(WEB_UPDATE_START, last - timedelta(days=7))
            else:
                start = WEB_UPDATE_START
            if start > today:
                start = today
            total = (today - start).days + 1
            for idx in range(total):
                day = start + timedelta(days=idx)
                try:
                    _, day_rows = fetch_day(day)
                    if day_rows:
                        rows.extend(day_rows)
                except urllib.error.HTTPError as exc:
                    if exc.code != 404:
                        errors.append(f"{day.strftime('%d/%m/%Y')}: HTTP {exc.code}")
                except Exception as exc:
                    errors.append(f"{day.strftime('%d/%m/%Y')}: {exc}")
            self.after(0, lambda: self._finish_web_update(start, today, rows, errors))
        except Exception as exc:
            self.after(0, lambda e=exc: self._web_update_failed(e))

    def _set_update_button_state(self, text, state):
        btn = getattr(self, "update_btn", None)
        try:
            if btn is not None and btn.winfo_exists():
                btn.configure(text=text, state=state)
        except Exception:
            pass

    def _web_update_failed(self, exc):
        self._web_update_running = False
        self._set_update_button_state("↻  BUSCAR ATUALIZAÇÃO", "normal")
        messagebox.showerror("Atualizar resultados", f"Não foi possível buscar os resultados.\n\n{exc}", parent=self)

    def _finish_web_update(self, start, end, rows, errors):
        self._web_update_running = False
        self._set_update_button_state("↻  BUSCAR ATUALIZAÇÃO", "normal")
        novos, alterados, iguais = self.reader.compare_web_rows(rows)
        if not novos and not alterados:
            msg = (
                "Não encontrei resultados novos ou corrigidos.\n\n"
                f"Fonte: Deu no Poste\n"
                f"Período verificado: {start.strftime('%d/%m/%Y')} a {end.strftime('%d/%m/%Y')}."
            )
            if errors:
                msg += f"\n\n{len(errors)} página(s) não puderam ser consultadas."
            messagebox.showinfo("Atualizar resultados", msg, parent=self)
            return

        msg = (
            f"Encontrei {len(novos)} prêmio(s) novo(s)"
            + (f" e {len(alterados)} correção(ões)" if alterados else "")
            + ".\n\nSerá criado um backup da base antes de aplicar.\n"
              "Somente a tabela de resultados será atualizada; Bilhetes, Financeiro e métodos não são alterados.\n\n"
              "Deseja aplicar agora?"
        )
        if not messagebox.askyesno("Atualizar resultados", msg, parent=self):
            return
        try:
            backup = self.reader.create_update_backup()
            apply_rows = list(novos) + [pair[0] for pair in alterados]
            changed = self.reader.apply_web_rows(apply_rows)
            if self.active_page == "search":
                self.show_search()
            elif self.active_page == "day_games":
                self.show_day_games(getattr(self, "_day_games_selected_date", None))
            else:
                self.show_home()
            detail = f"{changed} prêmio(s) gravado(s).\nBackup: {backup.name}"
            if errors:
                detail += f"\n\nAviso: {len(errors)} página(s) tiveram erro de acesso."
            messagebox.showinfo("Atualização concluída", detail, parent=self)
        except sqlite3.OperationalError as exc:
            messagebox.showerror(
                "Atualizar resultados",
                "Não consegui gravar a base. Se a Central principal estiver fazendo uma atualização neste momento, aguarde ela terminar e tente novamente.\n\n" + str(exc),
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror("Atualizar resultados", f"Falha ao aplicar a atualização.\n\n{exc}", parent=self)

    def choose_database(self):
        path = filedialog.askopenfilename(parent=self, title="Selecionar base histórica GP-H",
                                          filetypes=[("Banco SQLite", "*.db"), ("Todos os arquivos", "*.*")])
        if not path:
            return
        try:
            self.reader.set_path(Path(path))
            self._update_base_state()
            if self.active_page == "search": self.show_search()
            else: self.show_home()
        except Exception as e:
            messagebox.showerror("Base histórica", str(e), parent=self)

    def show_home(self):
        self._set_active("home")
        self._clear()
        self._tooltips.clear()
        # Cabeçalho compacto: libera altura útil para os 25 bichos, 5 prêmios e atrasos.
        home_head = tk.Frame(self.content, bg=COLORS["bg"])
        home_head.pack(fill="x", pady=(0, 5))
        tk.Label(
            home_head, text="Visão geral", bg=COLORS["bg"], fg=COLORS["text"],
            font=("Segoe UI Semibold", 16)
        ).pack(side="left")
        if self.reader.available():
            try:
                _summary_head = self.reader.summary()
                tk.Label(
                    home_head,
                    text=f"{_summary_head['extracoes']:,}".replace(",", ".") + " extrações na base",
                    bg=COLORS["bg"], fg=COLORS["muted"], font=("Segoe UI", 8)
                ).pack(side="right")
            except Exception:
                pass
        if not self.reader.available():
            self._empty_base_panel()
            return

        info = self.reader.summary()
        delays = self.reader.delay_leaders()
        counts = self.reader.group_counts()
        last_occ = self.reader.last_group_occurrences()

        # v0.1.11: Home alinhada ao padrão visual da Central principal, com reserva rígida de espaço para atrasos:
        # 25 bichos como protagonistas à esquerda e informações históricas à direita.
        main = tk.Frame(self.content, bg=COLORS["bg"])
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=59, uniform="homecols")
        main.grid_columnconfigure(1, weight=41, uniform="homecols")
        main.grid_rowconfigure(0, weight=1)

        # ------------------------------------------------------------------
        # ESQUERDA — 25 bichos em cartões quase quadrados.
        animals_panel = tk.Frame(
            main, bg=COLORS["card"], highlightbackground=COLORS["border"],
            highlightthickness=1, padx=7, pady=6
        )
        animals_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 5))

        animal_header = tk.Frame(animals_panel, bg=COLORS["card"])
        animal_header.pack(fill="x", pady=(0, 4))
        tk.Label(
            animal_header, text="OS 25 BICHOS", bg=COLORS["card"], fg=COLORS["text"],
            font=("Segoe UI Semibold", 12)
        ).pack(side="left")
        tk.Label(
            animal_header, text="Grupo • Bicho • 4 dezenas", bg=COLORS["card"], fg=COLORS["muted"],
            font=("Segoe UI", 8)
        ).pack(side="left", padx=(8, 0))

        grid = tk.Frame(animals_panel, bg=COLORS["card"])
        grid.pack(fill="both", expand=True)
        for row in range(5):
            grid.grid_rowconfigure(row, weight=1, uniform="animalrows", minsize=82)
        for col in range(5):
            grid.grid_columnconfigure(col, weight=1, uniform="animalcols", minsize=94)
        for idx, g in enumerate(range(1, 26)):
            r, c = divmod(idx, 5)
            self._animal_card(grid, g, counts.get(g, 0), r, c, last_occ.get(g))

        # ------------------------------------------------------------------
        # DIREITA — base/atualização, último resultado vertical e atrasos atuais.
        side = tk.Frame(main, bg=COLORS["bg"])
        side.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        # A coluna direita usa GRID: base e atrasos preservam sua altura natural,
        # enquanto Último Resultado recebe apenas o espaço restante. Isso é
        # importante no Windows com escala de tela/DPI acima de 100%, onde o
        # pack podia comprimir a última linha de Atrasos Atuais.
        side.grid_columnconfigure(0, weight=1)
        side.grid_rowconfigure(0, weight=0)
        side.grid_rowconfigure(1, weight=1, minsize=250)
        side.grid_rowconfigure(2, weight=0, minsize=106)

        # Base / atualização — informações gerais ficaram compactas, sem ocupar a Home toda.
        base_card = tk.Frame(
            side, bg=COLORS["card"], highlightbackground=COLORS["border"],
            highlightthickness=1, padx=11, pady=8
        )
        base_card.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        tk.Label(
            base_card, text="BASE HISTÓRICA", bg=COLORS["card"], fg=COLORS["muted"],
            font=("Segoe UI Semibold", 9)
        ).pack(anchor="w")
        periodo = f"{display_date(info['inicio'])} → {display_date(info['fim'])}"
        tk.Label(
            base_card, text=periodo, bg=COLORS["card"], fg=COLORS["text"],
            font=("Segoe UI Semibold", 14)
        ).pack(anchor="w", pady=(1, 1))
        resumo = (
            f"{info['extracoes']:,}".replace(",", ".") + " extrações  •  " +
            f"{info['premios']:,}".replace(",", ".") + " prêmios  •  " +
            f"{info['dias']:,}".replace(",", ".") + " dias"
        )
        tk.Label(base_card, text=resumo, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Segoe UI", 8)).pack(anchor="w")

        destaques = info.get("destaques", {})
        bicho_v, bicho_n = destaques.get("bicho", (None, 0))
        cent_v, cent_n = destaques.get("centena", (None, 0))
        dez_v, dez_n = destaques.get("dezena", (None, 0))
        mil_v, mil_n = destaques.get("milhar", (None, 0))
        freq = (
            f"Mais frequentes: {(bicho_v or '—').title()} {bicho_n}x  •  "
            f"Cent. {cent_v or '—'} {cent_n}x  •  Dez. {dez_v or '—'} {dez_n}x  •  "
            f"Milhar {mil_v or '—'} {mil_n}x"
        )
        tk.Label(base_card, text=freq, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Segoe UI", 7), anchor="w", justify="left", wraplength=430).pack(fill="x", pady=(3, 0))

        actions = tk.Frame(base_card, bg=COLORS["card"])
        actions.pack(fill="x", pady=(7, 0))
        self.update_btn = tk.Button(
            actions, text="↻  BUSCAR ATUALIZAÇÃO", command=self.check_for_updates,
            bd=0, relief="flat", cursor="hand2", bg=COLORS["accent"], fg="white",
            activebackground=COLORS["accent_hover"], activeforeground="white",
            font=("Segoe UI Semibold", 9), padx=12, pady=7
        )
        self.update_btn.pack(side="left")

        # Último resultado — leitura VERTICAL, prêmio por prêmio.
        latest_card = tk.Frame(
            side, bg=COLORS["card"], highlightbackground=COLORS["accent"],
            highlightthickness=1, padx=10, pady=8
        )
        latest_card.grid(row=1, column=0, sticky="nsew", pady=(0, 6))
        latest_head = tk.Frame(latest_card, bg=COLORS["card"])
        latest_head.pack(fill="x", pady=(0, 5))
        tk.Label(latest_head, text="ÚLTIMO RESULTADO", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Segoe UI Semibold", 12)).pack(side="left")

        if info["ultimo"]:
            u = list(info["ultimo"])
            head = u[0]
            tk.Label(
                latest_head, text=f"{display_date(head['data'])} • {head['sorteio']} {head['hora']}",
                bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 8)
            ).pack(side="right")
            prizes = tk.Frame(latest_card, bg=COLORS["card"])
            prizes.pack(fill="both", expand=True)
            prizes.grid_columnconfigure(0, weight=1)
            for _i in range(5):
                prizes.grid_rowconfigure(_i, weight=1, uniform="latest_prizes", minsize=34)
            for _i, r in enumerate(u[:5]):
                row = tk.Frame(
                    prizes, bg=COLORS["card2"], highlightbackground=COLORS["border"],
                    highlightthickness=1, padx=7, pady=3
                )
                row.grid(row=_i, column=0, sticky="nsew", pady=(0, 3))
                tk.Label(
                    row, text=f"{r['premio']}º", bg=COLORS["accent"], fg="white",
                    font=("Segoe UI Semibold", 9), width=3, padx=2, pady=2
                ).pack(side="left", padx=(0, 7))
                ident = tk.Frame(row, bg=COLORS["card2"])
                ident.pack(side="left", fill="x", expand=True)
                tk.Label(
                    ident, text=f"{r['bicho'].title()}  •  Grupo {int(r['grupo']):02d}",
                    bg=COLORS["card2"], fg=COLORS["text"], font=("Segoe UI Semibold", 9), anchor="w"
                ).pack(fill="x")
                tk.Label(
                    ident, text=f"Centena {r['centena']}  •  Dezena {r['dezena']}",
                    bg=COLORS["card2"], fg=COLORS["muted"], font=("Segoe UI", 7), anchor="w"
                ).pack(fill="x")
                tk.Label(
                    row, text=r["milhar"], bg=COLORS["card2"], fg=COLORS["accent_hover"],
                    font=("Consolas", 17, "bold")
                ).pack(side="right", padx=(8, 2))
        else:
            tk.Label(latest_card, text="Base ainda vazia.", bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Segoe UI", 9)).pack(anchor="w")

        # Atrasos atuais — maiores e mais fáceis de bater o olho.
        delay_card = tk.Frame(
            side, bg=COLORS["card"], highlightbackground=COLORS["border"],
            highlightthickness=1, padx=10, pady=7
        )
        delay_card.grid(row=2, column=0, sticky="ew")
        delay_head = tk.Frame(delay_card, bg=COLORS["card"])
        delay_head.pack(fill="x", pady=(0, 5))
        tk.Label(delay_head, text="ATRASOS ATUAIS", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Segoe UI Semibold", 11)).pack(side="left")
        tk.Label(delay_head, text="extrações desde a última aparição", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Segoe UI", 7)).pack(side="right")

        def delay_info(field, caption):
            item = delays.get(field)
            if not item:
                return "—", "—", "Sem dados suficientes na base.", None
            raw = item["value"]
            if field == "bicho":
                shown = BICHOS.get(int(raw), str(raw)).title()
                search_value = shown
            else:
                shown = str(raw).zfill(3 if field == "centena" else 2)
                search_value = shown
            plural = "extração" if item["delay"] == 1 else "extrações"
            tie = f" +{item['tie_count'] - 1} emp." if item["tie_count"] > 1 else ""
            delay_value = f"{item['delay']} {plural}{tie}"
            last = item["last"]
            tied_values = []
            for v in item["ties"][:6]:
                if field == "bicho":
                    tied_values.append(BICHOS.get(int(v), str(v)).title())
                else:
                    tied_values.append(str(v).zfill(3 if field == "centena" else 2))
            tie_detail = ""
            if item["tie_count"] > 1:
                rest = item["tie_count"] - len(tied_values)
                tie_detail = "\nEmpate: " + ", ".join(tied_values) + (f" +{rest}" if rest > 0 else "")
            tip = (
                f"{caption}: {shown}\n{item['delay']} {plural} sem aparecer\n"
                f"Última: {display_date(last['data'])} • {last['sorteio']} {last['hora']} • "
                f"{last['premio']}º prêmio • Milhar {last['milhar']}" + tie_detail
            )
            return shown, delay_value, tip, search_value

        row = tk.Frame(delay_card, bg=COLORS["card"])
        row.pack(fill="x")
        for idx, (field, caption, search_type) in enumerate((
            ("bicho", "Bicho", "Bicho"), ("centena", "Centena", "Centena"), ("dezena", "Dezena", "Dezena")
        )):
            shown, delay_value, tip, search_value = delay_info(field, caption)
            box = tk.Frame(
                row, bg=COLORS["card2"], highlightbackground=COLORS["border"],
                highlightthickness=1, padx=6, pady=7, cursor="hand2" if search_value else "arrow"
            )
            box.pack(side="left", fill="x", expand=True, padx=(0, 4 if idx < 2 else 0))
            cap = tk.Label(box, text=caption, bg=COLORS["card2"], fg=COLORS["muted"], font=("Segoe UI", 7))
            cap.pack(anchor="w")
            val = tk.Label(box, text=shown, bg=COLORS["card2"], fg=COLORS["text"], font=("Segoe UI Semibold", 10))
            val.pack(anchor="w")
            dl = tk.Label(box, text=delay_value, bg=COLORS["card2"], fg=COLORS["accent_hover"], font=("Segoe UI Semibold", 7))
            dl.pack(anchor="w")
            for w in (box, cap, val, dl):
                self._tooltips.append(HoverTip(w, tip))
                if search_value:
                    w.configure(cursor="hand2")
                    w.bind("<Button-1>", lambda _e, t=search_type, v=search_value: self.show_search(prefill=(t, v)), add="+")

    def _empty_base_panel(self):
        panel = tk.Frame(self.content, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
        panel.pack(fill="x", pady=20)
        tk.Label(panel, text="Base histórica não localizada", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI Semibold", 15)).pack(pady=(24, 6))
        tk.Label(panel, text="Se a GP-H Central Histórica estiver instalada neste PC, a Consulta normalmente encontra a base automaticamente.\nCaso contrário, selecione o arquivo gph_historico.db.",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 10), justify="center").pack(pady=(0, 16))
        ttk.Button(panel, text="Selecionar base histórica", style="Accent.TButton", command=self.choose_database).pack(pady=(0, 24))

    def _animal_card(self, parent, g, count, row, col, last_occurrence=None):
        # v0.1.10: cartão quase quadrado — grupo/nome + 4 dezenas sempre reservados.
        card = tk.Frame(
            parent, bg=COLORS["card2"], cursor="hand2",
            highlightbackground=COLORS["border"], highlightthickness=1
        )
        card.grid(row=row, column=col, sticky="nsew", padx=2, pady=2)

        # A faixa de identificação é empacotada primeiro e fica ancorada no
        # rodapé; a imagem recebe somente o espaço restante. Assim as quatro
        # dezenas nunca somem mesmo quando a altura da janela é menor.
        band = tk.Frame(card, bg=COLORS["entry"], cursor="hand2", height=32)
        band.pack(fill="x", side="bottom")
        band.pack_propagate(False)
        title = tk.Label(
            band, text=f"{g:02d} · {BICHOS[g].title()}", bg=COLORS["entry"], fg=COLORS["text"],
            font=("Segoe UI Semibold", 8), cursor="hand2", anchor="center"
        )
        title.pack(fill="x", pady=(2, 0))
        dezenas = tk.Label(
            band, text="  ".join(DEZENAS_POR_GRUPO[g]), bg=COLORS["entry"], fg=COLORS["accent_hover"],
            font=("Consolas", 8, "bold"), cursor="hand2", anchor="center"
        )
        dezenas.pack(fill="x", pady=(0, 2))

        visual = tk.Frame(card, bg=COLORS["card2"], cursor="hand2")
        visual.pack(fill="both", expand=True)
        image = self._load_image(
            f"animal_{g}",
            ANIMAL_DIR / f"{g:02d}_{sem_acento(BICHOS[g]).lower().replace(' ', '_')}.png",
            3,
        )
        if image is None:
            matches = list(ANIMAL_DIR.glob(f"{g:02d}_*.png"))
            if matches:
                image = self._load_image(f"animal_{g}", matches[0], 3)
        if image:
            animal = tk.Label(visual, image=image, bg=COLORS["card2"], cursor="hand2", bd=0)
        else:
            animal = tk.Label(visual, text="●", bg=COLORS["card2"], fg=COLORS["text"],
                              font=("Segoe UI", 22), cursor="hand2", bd=0)
        animal.pack(expand=True, pady=(1, 0))

        if last_occurrence:
            tip_text = (
                f"{BICHOS[g].title()} • Grupo {g:02d}\n"
                f"Dezenas: {'  '.join(DEZENAS_POR_GRUPO[g])}\n"
                f"Última: {display_date(last_occurrence['data'])} • {last_occurrence['sorteio']} {last_occurrence['hora']}\n"
                f"{last_occurrence['premio']}º prêmio • Milhar {last_occurrence['milhar']}"
            )
        else:
            tip_text = f"{BICHOS[g].title()} • Grupo {g:02d}\nSem ocorrência registrada na base."

        def go(_=None):
            self.show_search(prefill=("Bicho", BICHOS[g].title()))

        def enter(_=None):
            try:
                card.configure(highlightbackground=COLORS["accent_hover"])
            except Exception:
                pass

        def leave(_=None):
            try:
                card.configure(highlightbackground=COLORS["border"])
            except Exception:
                pass

        widgets = [card, visual, animal, band, title, dezenas]
        for w in widgets:
            try:
                w.bind("<Button-1>", go, add="+")
                w.bind("<Enter>", enter, add="+")
                w.bind("<Leave>", leave, add="+")
                self._tooltips.append(HoverTip(w, tip_text))
            except Exception:
                pass


    @staticmethod
    def _parse_day_games_date(value):
        if isinstance(value, date):
            return value
        value = str(value or "").strip()
        if not value:
            return date.today()
        for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                pass
        raise ValueError("Data inválida. Use dd/mm/aaaa.")

    def _day_games_move(self, days):
        try:
            base = self._parse_day_games_date(getattr(self, "_day_games_selected_date", None))
            self.show_day_games(base + timedelta(days=int(days)))
        except Exception as exc:
            messagebox.showerror("Jogos do dia", str(exc), parent=self)

    def _day_games_open_selected(self):
        try:
            self.show_day_games(self.day_games_date_var.get())
        except Exception as exc:
            messagebox.showerror("Jogos do dia", str(exc), parent=self)

    def _day_games_animal_image(self, group):
        try:
            g = int(group)
            path = ANIMAL_DIR / f"{g:02d}_{sem_acento(BICHOS[g]).lower().replace(' ', '_')}.png"
            image = self._load_image(f"day_animal_{g}", path, 7)
            if image is None:
                matches = list(ANIMAL_DIR.glob(f"{g:02d}_*.png"))
                if matches:
                    image = self._load_image(f"day_animal_{g}", matches[0], 7)
            return image
        except Exception:
            return None

    def _day_draw_card(self, parent, draw, row_index, col_index):
        card = tk.Frame(
            parent, bg=COLORS["card"], highlightbackground=COLORS["border"],
            highlightthickness=1, padx=9, pady=8
        )
        card.grid(row=row_index, column=col_index, sticky="nsew", padx=5, pady=5)

        head = tk.Frame(card, bg=COLORS["card"])
        head.pack(fill="x", pady=(0, 7))
        tk.Label(
            head, text=str(draw.get("hora") or "—"), bg=COLORS["card"], fg=COLORS["text"],
            font=("Segoe UI Semibold", 21)
        ).pack(side="left")
        tk.Label(
            head, text=str(draw.get("sorteio") or "").upper(), bg=COLORS["card"], fg=COLORS["accent_hover"],
            font=("Segoe UI Semibold", 10)
        ).pack(side="right", pady=(8, 0))

        prizes = list(draw.get("premios") or [])
        for idx in range(5):
            if idx < len(prizes):
                r = prizes[idx]
                row = tk.Frame(
                    card, bg=COLORS["card2"], highlightbackground=COLORS["border"],
                    highlightthickness=1, padx=6, pady=4
                )
                row.pack(fill="x", pady=(0, 4))
                tk.Label(
                    row, text=f"{int(r['premio'])}º", bg=COLORS["accent"], fg="white",
                    font=("Segoe UI Semibold", 9), width=3, padx=2, pady=2
                ).pack(side="left", padx=(0, 6))
                image = self._day_games_animal_image(r.get("grupo"))
                if image:
                    tk.Label(row, image=image, bg=COLORS["card2"], bd=0).pack(side="left", padx=(0, 6))
                ident = tk.Frame(row, bg=COLORS["card2"])
                ident.pack(side="left", fill="x", expand=True)
                tk.Label(
                    ident, text=f"{str(r['bicho']).title()} • Grupo {int(r['grupo']):02d}",
                    bg=COLORS["card2"], fg=COLORS["text"], font=("Segoe UI Semibold", 8), anchor="w"
                ).pack(fill="x")
                tk.Label(
                    ident, text=f"Centena {r['centena']} • Dezena {r['dezena']}",
                    bg=COLORS["card2"], fg=COLORS["muted"], font=("Segoe UI", 7), anchor="w"
                ).pack(fill="x")
                tk.Label(
                    row, text=str(r["milhar"]).zfill(4), bg=COLORS["card2"], fg=COLORS["accent_hover"],
                    font=("Consolas", 15, "bold")
                ).pack(side="right", padx=(6, 1))
            else:
                empty = tk.Frame(card, bg=COLORS["card2"], padx=7, pady=8)
                empty.pack(fill="x", pady=(0, 4))
                tk.Label(empty, text=f"{idx + 1}º  —", bg=COLORS["card2"], fg=COLORS["muted"],
                         font=("Segoe UI", 8)).pack(anchor="w")
        return card

    def show_day_games(self, day_value=None):
        self._set_active("day_games")
        self._clear()
        self._page_header(
            "Jogos do dia",
            "Veja todas as extrações registradas em uma data, cada uma em seu próprio cartão."
        )
        if not self.reader.available():
            self._empty_base_panel()
            return

        try:
            selected = self._parse_day_games_date(day_value)
        except ValueError:
            selected = date.today()
        self._day_games_selected_date = selected
        self.day_games_date_var = tk.StringVar(value=selected.strftime("%d/%m/%Y"))

        toolbar = tk.Frame(
            self.content, bg=COLORS["card"], highlightbackground=COLORS["border"],
            highlightthickness=1, padx=10, pady=8
        )
        toolbar.pack(fill="x", pady=(0, 8))
        tk.Button(
            toolbar, text="‹", command=lambda: self._day_games_move(-1),
            bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["card2"], fg=COLORS["text"],
            activebackground=COLORS["border"], activeforeground=COLORS["text"], font=("Segoe UI Semibold", 14)
        ).pack(side="left")
        self.day_games_entry = ttk.Entry(toolbar, textvariable=self.day_games_date_var, width=12, justify="center")
        self.day_games_entry.pack(side="left", padx=(6, 3))
        self.day_games_entry.bind("<Return>", lambda _e: self._day_games_open_selected())
        tk.Button(
            toolbar, text="📅", command=lambda: self.open_calendar(self.day_games_date_var, self.day_games_entry),
            bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["accent"], fg="white",
            activebackground=COLORS["accent_hover"], activeforeground="white", font=("Segoe UI Emoji", 10), pady=4
        ).pack(side="left", padx=(0, 4))
        ttk.Button(toolbar, text="Ver dia", command=self._day_games_open_selected).pack(side="left")
        tk.Button(
            toolbar, text="›", command=lambda: self._day_games_move(1),
            bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["card2"], fg=COLORS["text"],
            activebackground=COLORS["border"], activeforeground=COLORS["text"], font=("Segoe UI Semibold", 14)
        ).pack(side="left", padx=(5, 0))
        ttk.Button(toolbar, text="Hoje", command=lambda: self.show_day_games(date.today())).pack(side="left", padx=6)
        self.update_btn = tk.Button(
            toolbar, text="↻  ATUALIZAR RESULTADOS", command=self.check_for_updates,
            bd=0, relief="flat", cursor="hand2", bg=COLORS["accent"], fg="white",
            activebackground=COLORS["accent_hover"], activeforeground="white",
            font=("Segoe UI Semibold", 9), padx=12, pady=7
        )
        self.update_btn.pack(side="right")

        draws = self.reader.day_draws(selected)
        total_prizes = sum(len(d.get("premios") or []) for d in draws)
        is_today = selected == date.today()
        suffix = " até agora" if is_today else ""
        status = tk.Frame(self.content, bg=COLORS["bg"])
        status.pack(fill="x", pady=(0, 5))
        tk.Label(
            status,
            text=f"{selected.strftime('%d/%m/%Y')}  •  {len(draws)} extração(ões){suffix}  •  {total_prizes} prêmio(s)",
            bg=COLORS["bg"], fg=COLORS["muted"], font=("Segoe UI", 9)
        ).pack(side="left")

        if not draws:
            empty = tk.Frame(
                self.content, bg=COLORS["card"], highlightbackground=COLORS["border"],
                highlightthickness=1, padx=18, pady=28
            )
            empty.pack(fill="x", pady=(8, 0))
            tk.Label(
                empty, text="Nenhuma extração registrada nessa data.",
                bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI Semibold", 12)
            ).pack(anchor="w")
            tk.Label(
                empty, text="Use as setas para mudar o dia ou clique em Atualizar resultados.",
                bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 9)
            ).pack(anchor="w", pady=(3, 0))
            return

        scroll_host = tk.Frame(self.content, bg=COLORS["bg"])
        scroll_host.pack(fill="both", expand=True)
        canvas = tk.Canvas(scroll_host, bg=COLORS["bg"], highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(scroll_host, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        cards = tk.Frame(canvas, bg=COLORS["bg"])
        window_id = canvas.create_window((0, 0), window=cards, anchor="nw")
        cards.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))
        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(-1 * int(e.delta / 120), "units"))

        self.update_idletasks()
        columns = 3 if max(self.winfo_width(), 1) >= 1180 else 2
        for col in range(columns):
            cards.grid_columnconfigure(col, weight=1, uniform="day_draw_cols")
        for idx, draw in enumerate(draws):
            r, c = divmod(idx, columns)
            self._day_draw_card(cards, draw, r, c)

    def show_search(self, prefill=None):
        self._set_active("search")
        self._clear()
        self._page_header("Pesquisa", "Filtre os resultados e veja quais bichos, milhares, centenas e dezenas mais apareceram no recorte.")
        if not self.reader.available():
            self._empty_base_panel(); return

        filt = tk.Frame(self.content, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
        filt.pack(fill="x", pady=(0, 10))
        for i in range(9): filt.grid_columnconfigure(i, weight=1 if i in (1,3,4,5,6) else 0)

        self.var_type = tk.StringVar(value=prefill[0] if prefill else "Todos")
        self.var_value = tk.StringVar(value=prefill[1] if prefill else "")
        self.var_from = tk.StringVar()
        self.var_to = tk.StringVar()
        self.var_day = tk.StringVar()
        self.var_draw = tk.StringVar(value="Todos")
        self.var_prize = tk.StringVar(value="Todos")

        labels = [(0,"Pesquisar por"),(1,"Valor"),(3,"De"),(4,"Até"),(5,"Dia") ]
        for c, t in labels:
            tk.Label(filt, text=t, bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 8)).grid(row=0,column=c,sticky="w",padx=(10 if c==0 else 4,4),pady=(8,1))
        self.cb_type = ttk.Combobox(filt, textvariable=self.var_type, state="readonly", values=["Todos","Bicho","Grupo","Dezena","Centena","Milhar"], width=12)
        self.cb_type.grid(row=1,column=0,sticky="ew",padx=(10,4),pady=(0,8))
        ttk.Entry(filt, textvariable=self.var_value).grid(row=1,column=1,columnspan=2,sticky="ew",padx=4,pady=(0,8))

        from_box = tk.Frame(filt, bg=COLORS["card"])
        from_box.grid(row=1,column=3,sticky="ew",padx=4,pady=(0,8)); from_box.grid_columnconfigure(0, weight=1)
        self.entry_from = ttk.Entry(from_box, textvariable=self.var_from, width=11)
        self.entry_from.grid(row=0,column=0,sticky="ew")
        btn_cal_from = tk.Button(from_box, text="📅", command=lambda: self.open_calendar(self.var_from, self.entry_from),
                  bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["accent"], fg="white",
                  activebackground=COLORS["accent_hover"], activeforeground="white", font=("Segoe UI Emoji",10), pady=4)
        btn_cal_from.grid(row=0,column=1,padx=(4,0))
        self._tooltips.append(HoverTip(btn_cal_from, "Abrir calendário da data inicial"))

        to_box = tk.Frame(filt, bg=COLORS["card"])
        to_box.grid(row=1,column=4,sticky="ew",padx=4,pady=(0,8)); to_box.grid_columnconfigure(0, weight=1)
        self.entry_to = ttk.Entry(to_box, textvariable=self.var_to, width=11)
        self.entry_to.grid(row=0,column=0,sticky="ew")
        btn_cal_to = tk.Button(to_box, text="📅", command=lambda: self.open_calendar(self.var_to, self.entry_to),
                  bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["accent"], fg="white",
                  activebackground=COLORS["accent_hover"], activeforeground="white", font=("Segoe UI Emoji",10), pady=4)
        btn_cal_to.grid(row=0,column=1,padx=(4,0))
        self._tooltips.append(HoverTip(btn_cal_to, "Abrir calendário da data final"))

        day_box = tk.Frame(filt, bg=COLORS["card"])
        day_box.grid(row=1,column=5,sticky="ew",padx=4,pady=(0,8)); day_box.grid_columnconfigure(0, weight=1)
        self.entry_day = ttk.Entry(day_box, textvariable=self.var_day, width=11)
        self.entry_day.grid(row=0,column=0,sticky="ew")
        btn_cal_day = tk.Button(day_box, text="📅", command=lambda: self.open_calendar(self.var_day, self.entry_day),
                  bd=0, relief="flat", cursor="hand2", width=3, bg=COLORS["accent"], fg="white",
                  activebackground=COLORS["accent_hover"], activeforeground="white", font=("Segoe UI Emoji",10), pady=4)
        btn_cal_day.grid(row=0,column=1,padx=(4,0))
        self._tooltips.append(HoverTip(btn_cal_day, "Pesquisar um dia específico (tem prioridade sobre De/Até)"))

        tk.Label(filt, text="Rodada", bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 8)).grid(row=0,column=6,sticky="w",padx=4,pady=(8,1))
        draw_values = ["Todos"] + [f"{s} • {h}" for s,h in self.reader.draw_options()]
        self.cb_draw = ttk.Combobox(filt, textvariable=self.var_draw, state="readonly", values=draw_values, width=15)
        self.cb_draw.grid(row=1,column=6,sticky="ew",padx=4,pady=(0,8))
        tk.Label(filt, text="Prêmio", bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 8)).grid(row=0,column=7,sticky="w",padx=4,pady=(8,1))
        ttk.Combobox(filt, textvariable=self.var_prize, state="readonly", values=["Todos","1º","2º","3º","4º","5º"], width=8).grid(row=1,column=7,sticky="ew",padx=4,pady=(0,8))
        ttk.Button(filt, text="Pesquisar", style="Accent.TButton", command=self.run_search).grid(row=1,column=8,sticky="ew",padx=(5,10),pady=(0,8))

        # Filtro inteligente: Dia tem prioridade. Sem Dia, De/Até definem o recorte.
        # A lista de Rodada mostra somente extrações que realmente existem nesse recorte.
        self._draw_refresh_job = None
        self.var_from.trace_add("write", self._schedule_draw_options_refresh)
        self.var_to.trace_add("write", self._schedule_draw_options_refresh)
        self.var_day.trace_add("write", self._schedule_draw_options_refresh)

        # Ajuda visual dos calendários e regra de prioridade do Dia específico.
        cal_hint = tk.Label(self.content, text="📅  Dia pesquisa uma data específica e tem prioridade sobre De/Até. Para períodos, deixe Dia vazio e use De e Até.",
                            bg=COLORS["bg"], fg=COLORS["muted"], font=("Segoe UI", 8), anchor="w")
        cal_hint.pack(fill="x", pady=(0, 5))

        quick = tk.Frame(self.content, bg=COLORS["bg"])
        quick.pack(fill="x", pady=(0, 8))
        ttk.Button(quick, text="Limpar", command=self.clear_search).pack(side="left")
        ttk.Button(quick, text="Somente 1º prêmio", command=self.only_first).pack(side="left", padx=6)
        ttk.Button(quick, text="Recarregar", command=self.run_search).pack(side="left")
        ttk.Button(quick, text="Exportar CSV", command=self.export_csv).pack(side="right")

        self.summary_frame = tk.Frame(self.content, bg=COLORS["bg"])
        self.summary_frame.pack(fill="x", pady=(0, 9))
        self.summary_labels = []
        for i in range(4):
            f = tk.Frame(self.summary_frame, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
            f.grid(row=0,column=i,sticky="nsew",padx=(0 if i==0 else 6,0)); self.summary_frame.grid_columnconfigure(i,weight=1)
            lab = tk.Label(f, text="—", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI Semibold", 11), justify="left")
            lab.pack(anchor="w", padx=10, pady=8); self.summary_labels.append(lab)

        body = tk.Frame(self.content, bg=COLORS["bg"])
        body.pack(fill="both", expand=True)
        body.grid_rowconfigure(0, weight=1); body.grid_columnconfigure(0, weight=4); body.grid_columnconfigure(1, weight=2)

        table_box = tk.Frame(body, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
        table_box.grid(row=0,column=0,sticky="nsew",padx=(0,7))
        cols = ("data","sorteio","hora","premio","milhar","centena","dezena","grupo","bicho")
        self.tree = ttk.Treeview(table_box, columns=cols, show="headings")
        headings = {"data":"Data","sorteio":"Sorteio","hora":"Hora","premio":"Prêmio","milhar":"Milhar","centena":"Centena","dezena":"Dezena","grupo":"Grupo","bicho":"Bicho"}
        widths = {"data":82,"sorteio":75,"hora":60,"premio":60,"milhar":70,"centena":68,"dezena":60,"grupo":58,"bicho":105}
        for c in cols:
            self.tree.heading(c,text=headings[c]); self.tree.column(c,width=widths[c],anchor="center" if c!="bicho" else "w",stretch=c=="bicho")
        vs = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left",fill="both",expand=True); vs.pack(side="right",fill="y")

        rank_box = tk.Frame(body, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
        rank_box.grid(row=0,column=1,sticky="nsew")
        head = tk.Frame(rank_box, bg=COLORS["card"]); head.pack(fill="x", padx=10, pady=(9,6))
        tk.Label(head,text="Ranking do recorte",bg=COLORS["card"],fg=COLORS["text"],font=("Segoe UI Semibold",11)).pack(side="left")
        self.var_rank = tk.StringVar(value="Bichos")
        rank_cb = ttk.Combobox(head,textvariable=self.var_rank,state="readonly",values=["Bichos","Grupos","Dezenas","Centenas","Milhares"],width=11)
        rank_cb.pack(side="right"); rank_cb.bind("<<ComboboxSelected>>", lambda e:self.update_ranking())
        self.rank_tree = ttk.Treeview(rank_box, columns=("pos","valor","n","pct"), show="headings", height=15)
        for c,t,w in (("pos","#",35),("valor","Valor",120),("n","Vezes",55),("pct","%",55)):
            self.rank_tree.heading(c,text=t); self.rank_tree.column(c,width=w,anchor="center" if c!="valor" else "w",stretch=c=="valor")
        self.rank_tree.pack(fill="both", expand=True, padx=9, pady=(0,9))

        self.run_search()

    def open_calendar(self, target_var, anchor_widget):
        DatePickerPopup(self, target_var, anchor_widget)

    def _schedule_draw_options_refresh(self, *_):
        """Debounce para não consultar o SQLite a cada tecla digitada."""
        try:
            if self._draw_refresh_job:
                self.after_cancel(self._draw_refresh_job)
        except Exception:
            pass
        self._draw_refresh_job = self.after(180, self.refresh_draw_options)

    def refresh_draw_options(self):
        """Atualiza a Rodada conforme as datas válidas atualmente selecionadas."""
        self._draw_refresh_job = None
        if not hasattr(self, "cb_draw"):
            return
        raw_from = (self.var_from.get() or "").strip()
        raw_to = (self.var_to.get() or "").strip()
        raw_day = (self.var_day.get() or "").strip()

        # Dia específico tem prioridade sobre o intervalo. Enquanto o usuário
        # digita uma data incompleta, mantém a lista atual para evitar piscadas.
        try:
            if raw_day:
                d1 = d2 = parse_date(raw_day)
            else:
                d1 = parse_date(raw_from) if raw_from else None
                d2 = parse_date(raw_to) if raw_to else None
        except Exception:
            return
        if d1 and d2 and d1 > d2:
            return

        current = self.var_draw.get() or "Todos"
        values = ["Todos"] + [f"{s} • {h}" for s, h in self.reader.draw_options(d1, d2)]
        self.cb_draw.configure(values=values)
        if current not in values:
            self.var_draw.set("Todos")

    def _draw_parts(self):
        v = self.var_draw.get().strip()
        if v == "Todos" or " • " not in v: return None, None
        return tuple(x.strip() for x in v.split(" • ",1))

    def clear_search(self):
        self.var_type.set("Todos"); self.var_value.set(""); self.var_from.set(""); self.var_to.set(""); self.var_day.set(""); self.var_draw.set("Todos"); self.var_prize.set("Todos"); self.run_search()

    def only_first(self):
        self.var_prize.set("1º"); self.run_search()

    def run_search(self):
        try:
            day = parse_date(self.var_day.get())
            if day:
                d1 = d2 = day
            else:
                d1 = parse_date(self.var_from.get()); d2 = parse_date(self.var_to.get())
            self.refresh_draw_options()
            if d1 and d2 and d1 > d2: raise ValueError("A data inicial não pode ser maior que a final.")
            sorteio, hora = self._draw_parts()
            rows = self.reader.search(tipo=self.var_type.get(), valor=self.var_value.get(), date_from=d1, date_to=d2,
                                      sorteio=sorteio, hora=hora, premio=self.var_prize.get())
            self.last_rows = rows
            for item in self.tree.get_children(): self.tree.delete(item)
            for r in rows:
                self.tree.insert("","end",values=(display_date(r["data"]),r["sorteio"],r["hora"],f"{r['premio']}º",r["milhar"],r["centena"],r["dezena"],f"{r['grupo']:02d}",r["bicho"].title()))
            self.update_summary(rows); self.update_ranking()
        except Exception as e:
            messagebox.showerror("Pesquisa", str(e), parent=self)

    def update_summary(self, rows):
        total = len(rows)
        draws = len({(r["data"],r["sorteio"],r["hora"]) for r in rows})
        days = len({r["data"] for r in rows})
        latest = rows[0] if rows else None
        texts = [
            f"{total:,}\nprêmios".replace(",","."),
            f"{draws:,}\nextrações".replace(",","."),
            f"{days:,}\ndias".replace(",","."),
            (f"{display_date(latest['data'])}\núltima ocorrência" if latest else "—\núltima ocorrência"),
        ]
        for lab, text in zip(self.summary_labels, texts): lab.configure(text=text)

    def update_ranking(self):
        if not hasattr(self, "rank_tree"): return
        for i in self.rank_tree.get_children(): self.rank_tree.delete(i)
        rows = self.last_rows
        if not rows: return
        typ = self.var_rank.get()
        if typ == "Bichos": values = [r["bicho"].title() for r in rows]
        elif typ == "Grupos": values = [f"{r['grupo']:02d} - {r['bicho'].title()}" for r in rows]
        elif typ == "Dezenas": values = [r["dezena"] for r in rows]
        elif typ == "Centenas": values = [r["centena"] for r in rows]
        else: values = [r["milhar"] for r in rows]
        cnt = Counter(values); total = len(rows)
        for pos,(value,n) in enumerate(sorted(cnt.items(), key=lambda kv:(-kv[1], kv[0]))[:25],1):
            self.rank_tree.insert("","end",values=(pos,value,n,f"{n*100/total:.1f}%"))

    def export_csv(self):
        if not self.last_rows:
            messagebox.showinfo("Exportar", "Não há resultados para exportar.", parent=self); return
        path = filedialog.asksaveasfilename(parent=self,title="Exportar pesquisa",defaultextension=".csv",
                                            initialfile="GP-H_Consulta_Pesquisa.csv",filetypes=[("CSV","*.csv")])
        if not path: return
        with open(path,"w",encoding="utf-8-sig",newline="") as f:
            w = csv.writer(f,delimiter=";")
            w.writerow(["Data","Sorteio","Hora","Prêmio","Milhar","Centena","Dezena","Grupo","Bicho"])
            for r in self.last_rows:
                # prefixo = força Excel a preservar zeros à esquerda sem perder visualização textual.
                w.writerow([display_date(r["data"]),r["sorteio"],r["hora"],r["premio"],f'="{r["milhar"]}"',f'="{r["centena"]}"',f'="{r["dezena"]}"',f'="{r["grupo"]:02d}"',r["bicho"]])
        messagebox.showinfo("Exportar", f"Pesquisa exportada:\n{path}", parent=self)


def run_app():
    app = ConsultaApp()
    app.mainloop()


if __name__ == "__main__":
    run_app()
